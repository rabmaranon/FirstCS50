package DigitalJournalApp;

import java.util.Arrays;
import java.util.Objects;

/**
 * CmdLineProcessor is an object that processes user-input arguments taken from the main class.
 * These arguments are examined, compared, and modified accordingly for functions in main.
 */
public class CmdLineProcessor {
    private String[] userArgs;

    /**
     * Constructor for CmdLineProcessor
     *
     * @param userArgs - String array passed in from user-input via main
     */
    public CmdLineProcessor(String[] userArgs) {
        this.userArgs = userArgs;
    }

    /**
     * Checks whether an item exists within the String array
     * Helper method for the cmdLineChecker
     *
     * @param item - item to be compared with items in array
     * @return true if item is in array, false otherwise
     */
    protected boolean contains(String item) {
        for (int i = 0; i < this.userArgs.length; i++) {
            if (this.userArgs[i].equals(item)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if appropriate arguments are matched together and whether arguments exist
     *
     * @throws CommandLineException if arguments do not match accordingly or does not exist in array
     */
    protected void cmdLineChecker() throws CommandLineException {
        if (this.userArgs.length < 1) {
            throw new CommandLineException("");
        } else if (!contains(DigitalJournalCLA.ARG_CSV_PATH)) {
            throw new CommandLineException("A path to the journal is required");
        } else if (contains(DigitalJournalCLA.ARG_ADD_ENTRY) && !contains(DigitalJournalCLA.ARG_ENTRY_TEXT)) {
            throw new CommandLineException("-- entry text must also be provided");
        }
    }

    private boolean isSame(String text1, String[] textList) {
        for(int i = 0; i < textList.length; i++) {
            if(text1.equals(textList[i])) {
                return true;
            }
        }
        return false;
    }

    /**
     * retrieves input immediately following a given flag
     * @param index - index of flag

     * @return
     */
    protected String retrieveInputHelper(int index) {
        String textEntry = "";
        for (int j = index + 1; j < userArgs.length && !isSame(userArgs[j], DigitalJournalCLA.argsList); j++) {
            if (userArgs[index].equals(DigitalJournalCLA.ARG_CSV_PATH)) {
                textEntry += userArgs[j];
            } else {
                textEntry += userArgs[j] + " ";
            }
        }
        return textEntry;
    }

    protected String retrieveInput(String flag) {
        for (int i = 0; i < userArgs.length; i++) {
            if(userArgs[i].equals(flag)) {
                String text = this.retrieveInputHelper(i);
                return text;
            }
        }
        return null;
    }
}
