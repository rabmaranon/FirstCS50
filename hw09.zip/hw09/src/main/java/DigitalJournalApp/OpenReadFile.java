package DigitalJournalApp;

import java.io.BufferedReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * OpenReadFile is an object that has the responsibilities of opening the files and
 * compare them to the readable data. It has a uniq path for each files
 */
public class OpenReadFile {

    protected List<Map<String, String >> journalEntries;
    protected String path_csv;


    /**
     * Constructor that create a new OpenReadFile object with the specific path_csv,
     * path_email_template, and path_letter
     * @param path_csv - path_csv is the absolutePath represent the insurance_company_customers.csv

     */
    public OpenReadFile(String path_csv) {
        this.journalEntries = new ArrayList<>();
        this.path_csv = path_csv;
    }

    /**
     * Returns the list of customers in a hashmap format
     * The key is the header and value is the information of each customers
     * @return the list of customers in a hashmap format
     */
    public List<Map<String, String>> csvFile_handle() {
        String[] header_options;
        String head;
        try(BufferedReader inputFile = new BufferedReader(new FileReader(this.path_csv));)
        {
            head = inputFile.readLine();
            String row = "";

            header_options = head.split("\\W+");


            while((row = inputFile.readLine()) != null) {

                String[] row_list = row.split(",");

                Map<String, String> map = new LinkedHashMap<>();

                for (int i = 0; i < row_list.length; i++) {
                    map.put(header_options[i], row_list[i]);

                }
                journalEntries.add(map);
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("*** OOPS! A file was not found : " + e.getMessage());
            e.printStackTrace();
        }
        catch (IOException ioe) {
            System.out.println("Something went wrong! : " + ioe.getMessage());
            ioe.printStackTrace();
        }
        return journalEntries;
    }

    protected Integer getNewEntryIndex() {
        return this.journalEntries.size() + 1;
    }
}

