package DigitalJournalApp;

public class CommandLineException extends Exception {
    public CommandLineException(String message) {
        super(message);
    }
}
