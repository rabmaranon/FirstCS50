package DigitalJournalApp;

import java.time.LocalDate;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

public class DigitalEntry {
  private static final boolean DEFAULT_COMPLETE = false;

  private String txt;
  private boolean completed;
  private LocalDate date;
  private Integer priority;
  private String category;

  private DigitalEntry(Builder builder) {
    this.txt = builder.txt;
    this.completed = builder.completed;
    this.date = builder.date;
    this.priority = builder.priority;
    this.category = builder.category;
  }

  public String getTxt() {
    return txt;
  }

  public boolean isCompleted() {
    return completed;
  }

  public void setCompleted(boolean completed) {
    this.completed = completed;
  }

  public LocalDate getDate() {
    return date;
  }

  public Integer getPriority() {
    return priority;
  }

  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

//  @Override
//  public String toString() {
//    return "DigitalEntry{" +
//        "txt='" + txt + '\'' +
//        ", completed=" + completed +
//        ", date=" + date +
//        ", priority=" + priority +
//        ", category='" + category + '\'' +
//        '}';
//  }
  @Override
  public String toString() {
    return
        "\"" + completed + '\"' ;
  }

  public String toString(LocalDate date) {
    return
        "\"" + date + '\"' ;
  }

  public String toString(Integer priority) {
    return
        "\"" + priority + '\"' ;
  }

  public HashMap<String, String> addingDigitalEntry() {
    HashMap<String, String> digitalEntry = new HashMap<>();
    digitalEntry.put("text", txt);
    digitalEntry.put("completed", this.toString());
    digitalEntry.put("date", this.toString(this.date));
    digitalEntry.put("priority", this.toString(this.priority));
    digitalEntry.put("category", category);

    return digitalEntry;
  }

  public void update (HashMap<String, String> dic) {
    dic.replace("Completed", "true");
  }

  public static class Builder {

    private String txt;  // Required parameter
    private boolean completed;  // Default false
    private LocalDate date;  // Required parameter
    private Integer priority;  // Optional parameter
    private String category;  // Optional parameter

    public Builder (String txt, LocalDate date) {
      this.txt = txt;
      this.date = date;
      this.completed = DEFAULT_COMPLETE;
    }

    public Builder addPriority(Integer priority) {
      this.priority = priority;
      return this;
    }

    public Builder addCategory (String category) {
      this.category = category;
      return this;
    }

    public Builder complete() {
      this.completed = true;
      return this;
    }

    public DigitalEntry build() {
      return new DigitalEntry(this);
    }

  }


}
