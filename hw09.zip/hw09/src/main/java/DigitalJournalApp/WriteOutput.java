package DigitalJournalApp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Writes output to files
 */
public class WriteOutput {
    String fileName;



    /**
     * Constructor for WriteOutput
     * @param fileName - filename for output file


     * @throws IOException - If any IOException occurs when generating output to file
     */
    public WriteOutput(String fileName) throws IOException {
        this.fileName = fileName;

    }

    /**
     * Creates output directory specified by user directory and appends to filename for file output
     * Save new entry should be last in order of events
     */
    protected void saveNewEntry(String message) {
        BufferedWriter outputFile = null;
        String errString = new String("Failed to close input stream");

        try {
            outputFile = new BufferedWriter(new FileWriter(this.fileName, true));
            String line;
            line = message;
            outputFile.write(line);
        } catch (
                IOException ioe) {
            System.out.println("Something went wrong! : " + ioe.getMessage());
            ioe.printStackTrace();
        } finally {
            if (outputFile != null) {
                try {
                    outputFile.close();
                } catch (IOException e) {
                    System.out.println(errString);
                    e.printStackTrace();
                }
            }
        }
    }
}
