package DigitalJournalApp;


import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;



public class Main {

    private static String convertWithStream(Map<String, String> map){
        String mapAsString = map.values().stream().collect(Collectors.joining(","));
        return mapAsString;
    }

    public static void main(String[] args) throws CommandLineException, IOException {
        CmdLineProcessor cmdProcessor = new CmdLineProcessor(args);
        cmdProcessor.cmdLineChecker();

        String fileCSVPath = cmdProcessor.retrieveInput(DigitalJournalCLA.ARG_CSV_PATH);

        OpenReadFile digitalJournal = new OpenReadFile(fileCSVPath);
        List<Map<String, String>> listMaps = digitalJournal.csvFile_handle();
        WriteOutput writeOutput = new WriteOutput(fileCSVPath);//

        if (cmdProcessor.contains(DigitalJournalCLA.ARG_ENTRY_TEXT)){
            String textEntry = cmdProcessor.retrieveInput(DigitalJournalCLA.ARG_ENTRY_TEXT);

        } else if(cmdProcessor.contains(DigitalJournalCLA.ARG_COMPLETED)) {
            // set complete
        } else if(cmdProcessor.contains(DigitalJournalCLA.ARG_DATE)) {
            // set date
        } else if(cmdProcessor.contains(DigitalJournalCLA.ARG_PRIORITY)) {
            // set priority
        } else if(cmdProcessor.contains(DigitalJournalCLA.ARG_CATEGORY)) {
            // set category
        } else if(cmdProcessor.contains(DigitalJournalCLA.ARG_MARK_COMPLETE)) {
             String id = cmdProcessor.retrieveInput(DigitalJournalCLA.ARG_MARK_COMPLETE);
        } else if(cmdProcessor.contains(DigitalJournalCLA.ARG_DISPLAY)) {
            // do display
        } else if(cmdProcessor.contains(DigitalJournalCLA.ARG_SHOW_INCOMPLETE)) {
            // do show incomplete
        } else if(cmdProcessor.contains(DigitalJournalCLA.ARG_SHOW_CATEGORY)) {
            // do show category
        } else if(cmdProcessor.contains(DigitalJournalCLA.ARG_SORT_DATE)) {
            // do sort date
        } else if(cmdProcessor.contains(DigitalJournalCLA.ARG_SORT_PRIORITY)) {
            // do sort priority
        }

//        for(int i = 0; i < listMaps.size(); i++) {
//        }
//
//        Map<String, String> specifiedMap;
//        String id_header = "id";
//        String idNum = "3";
//        for (Map<String, String> map : listMaps) {
//
//            if (map.get(id_header).equals(idNum)){
//                specifiedMap =  map;
//
//                String stringMap = convertWithStream(specifiedMap);
//                writeOutput.saveNewEntry("\n" + stringMap);
//            }
//
//        }

//         Use this to test new entry(specifiedMap) map to CSV output
//        String stringMap = convertWithStream(specifiedMap);
//        writeOutput.saveNewEntry("\n" + stringMap);
//        System.out.println(openReadFile.getNewEntryIndex());




    }
}