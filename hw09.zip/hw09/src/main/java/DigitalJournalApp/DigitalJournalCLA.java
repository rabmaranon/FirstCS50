package DigitalJournalApp;

public class DigitalJournalCLA {
    protected final static String ARG_CSV_PATH = "--csv-file";
    protected final static String ARG_ADD_ENTRY = "--add-entry";
    protected final static String ARG_ENTRY_TEXT = "--entry-text";  // followed immediately by <description of entry>
    protected final static String ARG_COMPLETED= "--completed";
    protected final static String ARG_DATE = "--date";  // followed immediately by <date>
    protected final static String ARG_PRIORITY = "--priority";  // followed immediately by <1, 2, or 3>
    protected final static String ARG_CATEGORY= "--category";  // followed immediately by <a category name>
    protected final static String ARG_MARK_COMPLETE = "--complete-entry";  // followed immediately by <id>
    protected final static String ARG_DISPLAY = "--display";
    protected final static String ARG_SHOW_INCOMPLETE = "--show-incomplete";
    protected final static String ARG_SHOW_CATEGORY = "--show-category";  // followed immediately by <category>
    protected final static String ARG_SORT_DATE = "--sort-by-date";
    protected final static String ARG_SORT_PRIORITY = "--sort-by-priority";
    public static String[] argsList = {ARG_CSV_PATH, ARG_ADD_ENTRY, ARG_ENTRY_TEXT, ARG_COMPLETED, ARG_DATE,
            ARG_PRIORITY, ARG_CATEGORY,ARG_MARK_COMPLETE, ARG_DISPLAY, ARG_SHOW_INCOMPLETE, ARG_SHOW_CATEGORY,
            ARG_SORT_DATE, ARG_SORT_PRIORITY};
}
