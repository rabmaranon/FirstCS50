package OULAD.tools;

import OULAD.dao.AssessmentsDao;
import OULAD.dao.CoursesDao;
import OULAD.dao.StudentAssessmentDao;
import OULAD.dao.StudentInfoDao;
import OULAD.dao.StudentRegistrationDao;
import OULAD.dao.VleDao;
import OULAD.dao.VleStudentDao;
import OULAD.model.Assessments;
import OULAD.model.Courses;
import OULAD.model.StudentAssessment;
import OULAD.model.StudentInfo;
import OULAD.model.StudentRegistration;
import OULAD.model.Vle;
import OULAD.model.VleStudent;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/11/2020
 */
public class Inserter {

  public static final String vleReading = "Reading vle: id_site: %s, code_module: %s, " +
      "code_representation: %s, activity_type: %s";
  public static final String vleStudentReading =
      "Reading student_vle: id_site: %s, id_student: %s, " +
          "code_module: %s, code_presentation: $s";

  public static void main(String[] args) throws SQLException {
    // DAO instances.
    CoursesDao coursesDao = CoursesDao.getInstance();
    StudentInfoDao studentInfoDao = StudentInfoDao.getInstance();
    StudentRegistrationDao studentRegistrationDao = StudentRegistrationDao.getInstance();
    AssessmentsDao assessmentsDao = AssessmentsDao.getInstance();
    StudentAssessmentDao studentAssessmentDao = StudentAssessmentDao.getInstance();
/*U
    // INSERT objects from our model.
    // Courses
    Courses course = new Courses("ABC", "2020", 200);
    course = coursesDao.create(course);
    // Student Info
    StudentInfo studentInfo = new StudentInfo("ABC", "2020", 1,
        "M", "1", "U",
        "21", 1, 20,
        "US", "N", "pass");
    studentInfo = studentInfoDao.create(studentInfo);
    // Student Registration
    StudentRegistration studentRegistration = new StudentRegistration("ABC", "2020", 1, 0);
    studentRegistration = studentRegistrationDao.create(studentRegistration);
    // Assessments
    Assessments assessment = new Assessments("ABC", "2020", 1
        , "Q", 10, new BigDecimal("11.5"));
    assessment = assessmentsDao.create(assessment);
    // Student Assessment
    StudentAssessment studentAssessment = new StudentAssessment("ABC", "2020", 1, 1,
        10, 10, new Float("10.1"));
    studentAssessment = studentAssessmentDao.create(studentAssessment);

    // READ
    // Courses
    Courses c1 = coursesDao.getCourses("ABC", "2020");
    System.out
        .format("Reading course: m:%s p:%s l:%d\n", c1.getCode_module(), c1.getCode_presentation(),
            c1.getModule_presentation_length());
    // Student Info
    StudentInfo s1 = studentInfoDao.getStudentInfo("ABC", "2020", 1);
    System.out
        .format(
            "Reading student info: m:%s p:%s i:%d g:%s imd:%s h:%s a:%s n:%d c:%d r:%s d:%s f:%s\n"
            , s1.getCode_module(), s1.getCode_presentation(), s1.getId_student()
            , s1.getGender(), s1.getImd_band(), s1.getHighest_education()
            , s1.getAge_band(), s1.getNum_of_prev_attempts(), s1.getStudied_credits()
            , s1.getRegion(), s1.getDisability(), s1.getFinal_result());
    // Student Registration
    StudentRegistration sr1 = studentRegistrationDao.getStudentRegistration("ABC", "2020", 1);
    System.out
        .format("Reading student registration: m:%s p:%s id:%d d:%d\n", sr1.getCode_module(),
            sr1.getCode_presentation(),
            sr1.getId_student(), sr1.getDate_registration());
    // Assessment
    Assessments a1 = assessmentsDao.getAssessments("ABC", "2020", 1);
    System.out
        .format("Reading assessment: m:%s p:%s id:%d\n", a1.getCode_module(),
            a1.getCode_presentation(),
            a1.getId_assessment());
    // Student Assessment
    StudentAssessment sa1 = studentAssessmentDao.getStudentAssessment("ABC", "2020", 1, 1);
    System.out
        .format("Reading student assessment: m:%s p:%s id:%d id:d% date:%d bank:%d score:%f\n",
            sa1.getCode_module(),
            sa1.getCode_presentation(),
            sa1.getId_assessment(), sa1.getId_student(), studentAssessment.getDate_submitted(),
            studentAssessment.getIs_banked(), studentAssessment.getScore());

    // UPDATE
    // Courses
    Courses cu = coursesDao.updateModule_presentation_length(course, 100);
    System.out
        .format("Reading course: m:%s p:%s l:%d\n", cu.getCode_module(), cu.getCode_presentation(),
            cu.getModule_presentation_length());
    // Student Info
    StudentInfo nu = studentInfoDao.updateNum_of_prev_attempts(studentInfo, 2);
    System.out
        .format(
            "Reading student info: m:%s p:%s i:%d n:%d\n"
            , nu.getCode_module(), nu.getCode_presentation(), nu.getId_student()
            , nu.getNum_of_prev_attempts());
    StudentInfo nu1 = studentInfoDao.updateStudied_credits(studentInfo, 100);
    System.out
        .format(
            "Reading student info: m:%s p:%s i:%d c:%d\n"
            , nu1.getCode_module(), nu1.getCode_presentation(), nu1.getId_student()
            , nu1.getStudied_credits());
    // Student Registration
    StudentRegistration sru = studentRegistrationDao
        .updateDate_registration(studentRegistration, 1);
    System.out
        .format("Reading student registration: m:%s p:%s id:%d d:%d\n", sr1.getCode_module(),
            sr1.getCode_presentation(),
            sr1.getId_student(), sr1.getDate_registration());
    // Student Assessment
    StudentAssessment sau = studentAssessmentDao.updateScore(studentAssessment, new Float("100"));
    System.out
        .format("Reading student assessment: m:%s p:%s id:%d id:d% date:%d bank:%d score:%f\n",
            sa1.getCode_module(),
            sa1.getCode_presentation(),
            sa1.getId_assessment(), sa1.getId_student(), studentAssessment.getDate_submitted(),
            studentAssessment.getIs_banked(), studentAssessment.getScore());

    // DELETE
    // Student Assessment
    StudentAssessment deletedStudentAssessment = studentAssessmentDao.delete(studentAssessment);
    System.out.println("Deleted 1st StudentAssessment:" + deletedStudentAssessment + "\n");
    // Student Registration
    StudentRegistration deletedStudentRegistration = studentRegistrationDao
        .delete(studentRegistration);
    System.out.println("Deleted 1st StudentRegistration:" + deletedStudentRegistration + "\n");
    // Student Info
    StudentInfo deletedStudent = studentInfoDao.delete(studentInfo);
    System.out.println("Deleted 1st Student:" + deletedStudent + "\n");
    // Assessments
    Assessments deletedAssessment = assessmentsDao.delete(assessment);
    System.out.println("Deleted 1st Assessment:" + deletedAssessment + "\n");
    // Courses
    Courses deletedCourse = coursesDao.delete(course);
    System.out.println("Deleted 1st Course:" + deletedCourse + "\n");
    */
    // Vle_student and Vle CRUD
    //Create
    VleStudentDao vleStudentDao = VleStudentDao.getInstance();
    VleDao vleDao = VleDao.getInstance();
    Vle vle1 = new Vle(546652, "AAA", "2013J", "forumng");
    Vle vle2 = new Vle(546675, "AAA", "2013J", "oucontent");
    StudentInfo studentInfo1 = new StudentInfo("AAA", "2013J", 28400,
        "F", "20-30%", "HE Qualification",
        "21", 1, 20,
        "US", "N", "pass");
    StudentInfo studentInfo2 = new StudentInfo("AAA", "2013J", 71361,
        "M", "", "HE Qualification",
        "21", 0, 60,
        "US", "N", "pass");
    Courses course1 = new Courses("AAA", "2013J", 268);
    coursesDao.create(course1);
    studentInfoDao.create(studentInfo1);
    vleDao.create(vle1);
    vleDao.create(vle2);

    VleStudent student1 = new VleStudent(546652, 28400,
        "AAA", "2013J", -10, 4);
    vleStudentDao.create(student1);

    //Read VleStudent and Vle
    List<Vle> getVle1 = vleDao.getVleByIdSite(546652);
    for (Vle v : getVle1) {
      readVle(v);
    }

    Vle vleGet = vleDao.getVleByPrimaryKeys(546675, "AAA", "2013J");
    readVle(vleGet);

    List<VleStudent> students = vleStudentDao.getVleStudentById(28400);
    for (VleStudent s : students) {
      readVleStudent(s);


    }
    //Update VleStudent and Vle

    //delete VleStudent and Vle
    vleStudentDao.delete(student1);
    vleDao.delete(vle1);
  }

  public static void readVle(Vle vle) {
    System.out.println(String.format(vleReading, vle.getId_site(), vle.getCode_module(),
        vle.getCode_presentation(), vle.getActivity_type()));
  }

  public static void readVleStudent(VleStudent student) {
    System.out
        .println(String.format(vleStudentReading, student.getId_site(), student.getId_student(),
            student.getCode_module(), student.getCode_presentation()));

  }

}
