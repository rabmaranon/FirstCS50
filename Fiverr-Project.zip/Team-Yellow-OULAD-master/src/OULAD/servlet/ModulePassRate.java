package OULAD.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import OULAD.dao.StudentInfoDao;
import OULAD.model.StudentInfo;

@WebServlet("/passrate")
public class ModulePassRate extends HttpServlet {
    protected StudentInfoDao studentInfoDao;
    
    @Override
    public void init() throws ServletException {
        studentInfoDao = StudentInfoDao.getInstance();
    }
    
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
        
        Map<String, Double> modulePassRate = new HashMap<>();
            try {
            	modulePassRate = studentInfoDao.getModulePassRate();
            } catch (SQLException e) {
                e.printStackTrace();
                throw new IOException(e);
            }
            messages.put("success", "Displaying module pass rates");
        req.setAttribute("modules", modulePassRate);
        
        req.getRequestDispatcher("/ModulePassRate.jsp").forward(req, resp);
    }

}
