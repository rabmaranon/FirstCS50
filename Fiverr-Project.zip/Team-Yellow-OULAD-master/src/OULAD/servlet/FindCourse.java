package OULAD.servlet;

import OULAD.dao.CoursesDao;
import OULAD.model.Courses;

import javax.servlet.annotation.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/findcourse")
public class FindCourse extends HttpServlet {
    protected CoursesDao coursesDao;
    
    @Override
    public void init() throws ServletException {
        coursesDao = CoursesDao.getInstance();
    }

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
        
        List<Courses> coursesList = new ArrayList<>();
        String code_module = req.getParameter("code_module");
        
        if (code_module == null || code_module.trim().isEmpty()) {
            messages.put("success", "Please enter a id_site.");
        } else {
            // Retrieve Courses, and store as a message.
            try {
                coursesList = coursesDao.getCoursesByModule(code_module);
            } catch (SQLException e) {
                e.printStackTrace();
                throw new IOException(e);
            }
            messages.put("success", "Displaying results for " + code_module);
            // Save the previous search term, so it can be used as the default
            // in the input box when rendering FindUsers.jsp.
            messages.put("previousIdSite", code_module);
        }
        req.setAttribute("courses", coursesList);
        
        req.getRequestDispatcher("/FindCourse.jsp").forward(req, resp);
    }
    
    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);

        List<Courses> coursesList = new ArrayList<>();
        
        // Courses code_module is retrieved from the form POST submission. By default, it
        // is populated by the URL query string (in FindCourse.jsp).
        String code_module = req.getParameter("code_module");
        if (code_module == null || code_module.trim().isEmpty()) {
            messages.put("success", "Please enter a valid code_module.");
        } else {
            // Retrieve BlogUsers, and store as a message.
            try {
            	coursesList = coursesDao.getCoursesByModule(code_module);
            } catch (SQLException e) {
                e.printStackTrace();
                throw new IOException(e);
            }
            messages.put("success", "Displaying results for " + code_module);
        }
        System.out.println(coursesList.size());
        req.setAttribute("courses", coursesList);
        
        req.getRequestDispatcher("/FindCourse.jsp").forward(req, resp);
    }

}


