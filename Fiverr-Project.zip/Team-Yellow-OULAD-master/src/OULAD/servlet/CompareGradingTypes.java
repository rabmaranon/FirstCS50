package OULAD.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import OULAD.dao.AssessmentsDao;

@WebServlet("/comparegradingtypes")
public class CompareGradingTypes extends HttpServlet {
	protected AssessmentsDao assessmentsDao; 

	@Override 
	public void init() throws ServletException {
		assessmentsDao = AssessmentsDao.getInstance();
	}
	
	@Override 
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
        
        Map<String, Integer> typeToCount = new HashMap<>();
        try {
        	typeToCount = assessmentsDao.compareAssessmentTypes();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new IOException(e);
        }
        
        messages.put("success", "Dispaying grading types and the number of students who pass");
        req.setAttribute("typeToCount", typeToCount);
        req.getRequestDispatcher("/CompareGradingTypes.jsp").forward(req, resp);

	}
}
