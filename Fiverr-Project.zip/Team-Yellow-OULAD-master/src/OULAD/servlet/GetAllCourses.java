package OULAD.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import OULAD.dao.CoursesDao;
import OULAD.model.Courses;

@WebServlet("/getallcourses")
public class GetAllCourses extends HttpServlet {
	
	protected CoursesDao coursesDao;
	
	@Override 
	public void init() throws ServletException {
		coursesDao = CoursesDao.getInstance();
	}
	
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
		 // Map for storing messages.
        Map<String, String> messages = new HashMap<String, String>();
        req.setAttribute("messages", messages);
        
        List<Courses> coursesList = new ArrayList<>();
        try {
        	coursesList = coursesDao.getAllCourses();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new IOException(e);
        }
        messages.put("success", "Displaying all courses");
        
        req.setAttribute("courses", coursesList);
        
        req.getRequestDispatcher("/GetAllCourses.jsp").forward(req, resp);
	}

}
