package OULAD.model;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/13/2020
 */
public class StudentAssessment {

  private final String code_module;
  private final String code_presentation;
  private final int id_student;
  private final int id_assessment;
  private int date_submitted;
  private int is_banked;
  private float score;

  public StudentAssessment(String code_module, String code_presentation, int id_student,
      int id_assessment) {
    this.code_module = code_module;
    this.code_presentation = code_presentation;
    this.id_student = id_student;
    this.id_assessment = id_assessment;
  }

  public StudentAssessment(String code_module, String code_presentation, int id_student,
      int id_assessment, int date_submitted, int is_banked, float score) {
    this.code_module = code_module;
    this.code_presentation = code_presentation;
    this.id_student = id_student;
    this.id_assessment = id_assessment;
    this.date_submitted = date_submitted;
    this.is_banked = is_banked;
    this.score = score;
  }

  public String getCode_module() {
    return code_module;
  }

  public String getCode_presentation() {
    return code_presentation;
  }

  public int getId_student() {
    return id_student;
  }

  public int getId_assessment() {
    return id_assessment;
  }

  public int getDate_submitted() {
    return date_submitted;
  }

  public void setDate_submitted(int date_submitted) {
    this.date_submitted = date_submitted;
  }

  public int getIs_banked() {
    return is_banked;
  }

  public void setIs_banked(int is_banked) {
    this.is_banked = is_banked;
  }

  public float getScore() {
    return score;
  }

  public void setScore(float score) {
    this.score = score;
  }

}

