package OULAD.model;

public class Vle {
    protected int id_site;
    protected String code_module;
    protected String code_presentation;
    protected String activity_type;

    public Vle(int id_site, String code_module, String code_presentation, String activity_type) {
        this.id_site = id_site;
        this.code_module = code_module;
        this.code_presentation = code_presentation;
        this.activity_type = activity_type;
    }

    public Vle(int id_site, String code_module, String code_presentation) {
        this.id_site = id_site;
        this.code_module = code_module;
        this.code_presentation = code_presentation;
    }

    public int getId_site() {
        return id_site;
    }

    public String getCode_module() {
        return code_module;
    }

    public String getCode_presentation() {
        return code_presentation;
    }

    public String getActivity_type() {
        return activity_type;
    }

    public void setId_site(int id_site) {
        this.id_site = id_site;
    }

    public void setCode_module(String code_module) {
        this.code_module = code_module;
    }

    public void setCode_presentation(String code_presentation) {
        this.code_presentation = code_presentation;
    }

    public void setActivity_type(String activity_type) {
        this.activity_type = activity_type;
    }
}
