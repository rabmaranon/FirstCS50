package OULAD.model;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/11/2020
 */
public class Courses {

  private final String code_module;
  private final String code_presentation;
  private int module_presentation_length;

  public Courses(String code_module, String code_presentation, int module_presentation_length){
    this.code_module = code_module;
    this.code_presentation = code_presentation;
    this.module_presentation_length = module_presentation_length;
  }

  public Courses(String code_module, String code_presentation){
    this.code_module = code_module;
    this.code_presentation = code_presentation;
  }

  public String getCode_module() {
    return code_module;
  }

  public String getCode_presentation() {
    return code_presentation;
  }

  public int getModule_presentation_length() {
    return module_presentation_length;
  }

  public void setModule_presentation_length(int module_presentation_length) {
    this.module_presentation_length = module_presentation_length;
  }

}
