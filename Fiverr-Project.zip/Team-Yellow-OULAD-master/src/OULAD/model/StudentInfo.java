package OULAD.model;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/11/2020
 */
public class StudentInfo {

  private final String code_module;
  private final String code_presentation;
  private final int id_student;
  private String gender;
  private String imd_band;
  private String highest_education;
  private String age_band;
  private int num_of_prev_attempts;
  private int studied_credits;
  private String region;
  private String disability;
  private String final_result;
  private int count;

  public StudentInfo(String code_module, String code_presentation, int id_student) {
    this.code_module = code_module;
    this.code_presentation = code_presentation;
    this.id_student = id_student;
  }
  
  public StudentInfo(String code_module, int count) {
      this.code_module = code_module;
      this.count = count;
      this.id_student = 0;
      this.code_presentation = null;
  }
  
  public int getCount() {
      return this.count;
  }

  public StudentInfo(String code_module, String code_presentation, int id_student, String gender,
      String imd_band, String highest_education, String age_band, int num_of_prev_attempts,
      int studied_credits, String region, String disability, String final_result) {
    this.code_module = code_module;
    this.code_presentation = code_presentation;
    this.id_student = id_student;
    this.gender = gender;
    this.imd_band = imd_band;
    this.highest_education = highest_education;
    this.age_band = age_band;
    this.num_of_prev_attempts = num_of_prev_attempts;
    this.studied_credits = studied_credits;
    this.region = region;
    this.disability = disability;
    this.final_result = final_result;
  }

  public String getCode_module() {
    return code_module;
  }

  public String getCode_presentation() {
    return code_presentation;
  }

  public int getId_student() {
    return id_student;
  }

  public String getGender() {
    return gender;
  }

  public void setGender(String gender) {
    this.gender = gender;
  }

  public String getImd_band() {
    return imd_band;
  }

  public void setImd_band(String imd_band) {
    this.imd_band = imd_band;
  }

  public String getHighest_education() {
    return highest_education;
  }

  public void setHighest_education(String highest_education) {
    this.highest_education = highest_education;
  }

  public String getAge_band() {
    return age_band;
  }

  public void setAge_band(String age_band) {
    this.age_band = age_band;
  }

  public int getNum_of_prev_attempts() {
    return num_of_prev_attempts;
  }

  public void setNum_of_prev_attempts(int num_of_prev_attempt) {
    this.num_of_prev_attempts = num_of_prev_attempt;
  }

  public int getStudied_credits() {
    return studied_credits;
  }

  public void setStudied_credits(int studied_credits) {
    this.studied_credits = studied_credits;
  }

  public String getRegion() {
    return region;
  }

  public void setRegion(String region) {
    this.region = region;
  }

  public String getDisability() {
    return disability;
  }

  public void setDisability(String disability) {
    this.disability = disability;
  }

  public String getFinal_result() {
    return final_result;
  }

  public void setFinal_result(String final_result) {
    this.final_result = final_result;
  }

}
