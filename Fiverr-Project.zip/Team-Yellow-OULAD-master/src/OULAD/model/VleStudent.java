package OULAD.model;

public class VleStudent {
    protected int id_site;
    protected int id_student;
    protected String code_module;
    protected String code_presentation;
    protected int vle_date;
    protected int click_sum;

    public VleStudent(int id_site, int id_student, String code_module, String code_presentation, int vle_date, int click_sum) {
        this.id_site = id_site;
        this.id_student = id_student;
        this.code_module = code_module;
        this.code_presentation = code_presentation;
        this.vle_date = vle_date;
        this.click_sum = click_sum;
    }

    public VleStudent(int id_site, int id_student, String code_module, String code_presentation) {
        this.id_site = id_site;
        this.id_student = id_student;
        this.code_module = code_module;
        this.code_presentation = code_presentation;
    }

    public int getId_site() {
        return id_site;
    }

    public int getId_student() {
        return id_student;
    }

    public String getCode_module() {
        return code_module;
    }

    public String getCode_presentation() {
        return code_presentation;
    }

    public int getVle_date() {
        return vle_date;
    }

    public int getClick_sum() {
        return click_sum;
    }

    public void setId_site(int id_site) {
        this.id_site = id_site;
    }

    public void setId_student(int id_student) {
        this.id_student = id_student;
    }

    public void setCode_module(String code_module) {
        this.code_module = code_module;
    }

    public void setCode_presentation(String code_presentation) {
        this.code_presentation = code_presentation;
    }

    public void setVle_date(int vle_date) {
        this.vle_date = vle_date;
    }

    public void setClick_sum(int click_sum) {
        this.click_sum = click_sum;
    }
}
