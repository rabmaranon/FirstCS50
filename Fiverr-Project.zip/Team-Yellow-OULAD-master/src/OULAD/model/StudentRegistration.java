package OULAD.model;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/12/2020
 */
public class StudentRegistration {

  private final String code_module;
  private final String code_presentation;
  private final int id_student;
  private int date_registration;

  public StudentRegistration(String code_module, String code_presentation, int id_student) {
    this.code_module = code_module;
    this.code_presentation = code_presentation;
    this.id_student = id_student;
  }

  public StudentRegistration(String code_module, String code_presentation, int id_student,
      int date_registration) {
    this.code_module = code_module;
    this.code_presentation = code_presentation;
    this.id_student = id_student;
    this.date_registration = date_registration;
  }

  public String getCode_module() {
    return code_module;
  }

  public String getCode_presentation() {
    return code_presentation;
  }

  public int getId_student() {
    return id_student;
  }

  public int getDate_registration() {
    return date_registration;
  }

  public void setDate_registration(int date_registration) {
    this.date_registration = date_registration;
  }

}
