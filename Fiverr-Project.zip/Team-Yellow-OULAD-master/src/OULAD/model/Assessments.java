package OULAD.model;

import java.math.BigDecimal;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/13/2020
 */
public class Assessments {

  private final String code_module;
  private final String code_presentation;
  private final int id_assessment;
  private String assessment_type;
  private int assessment_date;
  private BigDecimal assessment_weight;

  public Assessments(String code_module, String code_presentation, int id_assessment) {
    this.code_module = code_module;
    this.code_presentation = code_presentation;
    this.id_assessment = id_assessment;
  }

  public Assessments(String code_module, String code_presentation, int id_assessment,
      String assessment_type, int assessment_date, BigDecimal assessment_weight) {
    this.code_module = code_module;
    this.code_presentation = code_presentation;
    this.id_assessment = id_assessment;
    this.assessment_type = assessment_type;
    this.assessment_date = assessment_date;
    this.assessment_weight = assessment_weight;
  }

  public String getCode_module() {
    return code_module;
  }

  public String getCode_presentation() {
    return code_presentation;
  }

  public int getId_assessment() {
    return id_assessment;
  }

  public String getAssessment_type() {
    return assessment_type;
  }

  public void setAssessment_type(String assessment_type) {
    this.assessment_type = assessment_type;
  }

  public int getAssessment_date() {
    return assessment_date;
  }

  public void setAssessment_date(int assessment_date) {
    this.assessment_date = assessment_date;
  }

  public BigDecimal getAssessment_weight() {
    return assessment_weight;
  }

  public void setAssessment_weight(BigDecimal assessment_weight) {
    this.assessment_weight = assessment_weight;
  }

}
