package OULAD.dao;

import OULAD.model.StudentRegistration;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/12/2020
 */
public class StudentRegistrationDao {

  private static StudentRegistrationDao instance = null;
  protected ConnectionManager connectionManager;

  protected StudentRegistrationDao() {
    connectionManager = new ConnectionManager();
  }

  public static StudentRegistrationDao getInstance() {
    if (instance == null) {
      instance = new StudentRegistrationDao();
    }
    return instance;
  }

  public StudentRegistration create(StudentRegistration studentRegistration) throws SQLException {
    String insertStudentRegistration =
        "INSERT INTO student_registration(code_module,code_presentation,"
            + "id_student, date_registration) VALUES(?,?,?,?);";
    Connection connection = null;
    PreparedStatement insertStmt = null;
    try {
      connection = connectionManager.getConnection();
      insertStmt = connection.prepareStatement(insertStudentRegistration);

      insertStmt.setString(1, studentRegistration.getCode_module());
      insertStmt.setString(2, studentRegistration.getCode_presentation());
      insertStmt.setInt(3, studentRegistration.getId_student());
      insertStmt.setInt(4, studentRegistration.getDate_registration());

      insertStmt.executeUpdate();

      return studentRegistration;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (insertStmt != null) {
        insertStmt.close();
      }
    }
  } // end of create

  public StudentRegistration getStudentRegistration(String code_module, String code_presentation,
      int id_student)
      throws SQLException {
    String selectStudentRegistration = "SELECT * FROM student_registration "
        + "WHERE code_module=? AND code_presentation=? AND id_student=?;";
    Connection connection = null;
    PreparedStatement selectStmt = null;
    ResultSet results = null;
    try {
      connection = connectionManager.getConnection();
      selectStmt = connection.prepareStatement(selectStudentRegistration);
      selectStmt.setString(1, code_module);
      selectStmt.setString(2, code_presentation);
      selectStmt.setInt(3, id_student);
      results = selectStmt.executeQuery();

      if (results.next()) {
        String resultCode_module = results.getString("code_module");
        String resultCode_presentation = results.getString("code_presentation");
        int resultId_student = results.getInt("id_student");
        int resultDate_registration = results.getInt("date_registration");

        StudentRegistration studentRegistration = new StudentRegistration(resultCode_module,
            resultCode_presentation,
            resultId_student, resultDate_registration);

        return studentRegistration;
      }
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (selectStmt != null) {
        selectStmt.close();
      }
      if (results != null) {
        results.close();
      }
    }
    return null;

  } // end of get

  public StudentRegistration updateDate_registration(StudentRegistration studentRegistration,
      int newDate_registration)
      throws SQLException {
    String updateDate_registration = "UPDATE student_registration SET date_registration=? "
        + "WHERE code_module=? AND code_presentation=? AND id_student=?;";
    Connection connection = null;
    PreparedStatement updateStmt = null;
    try {
      connection = connectionManager.getConnection();
      updateStmt = connection.prepareStatement(updateDate_registration);
      updateStmt.setInt(1, newDate_registration);
      updateStmt.setString(2, studentRegistration.getCode_module());
      updateStmt.setString(3, studentRegistration.getCode_presentation());
      updateStmt.setInt(4, studentRegistration.getId_student());
      updateStmt.executeUpdate();

      // Update the company param before returning to the caller.
      studentRegistration.setDate_registration(newDate_registration);
      return studentRegistration;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (updateStmt != null) {
        updateStmt.close();
      }
    }

  } // end of update

  public StudentRegistration delete(StudentRegistration studentRegistration) throws SQLException {
    String deleteStudentRegistration = "DELETE FROM student_registration "
        + "WHERE code_module=? AND code_presentation=? AND id_student=?;";
    Connection connection = null;
    PreparedStatement deleteStmt = null;
    try {
      connection = connectionManager.getConnection();
      deleteStmt = connection.prepareStatement(deleteStudentRegistration);
      deleteStmt.setString(1, studentRegistration.getCode_module());
      deleteStmt.setString(2, studentRegistration.getCode_presentation());
      deleteStmt.setInt(3, studentRegistration.getId_student());
      deleteStmt.executeUpdate();

      // Return null so the caller can no longer operate on the Persons instance.
      return null;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (deleteStmt != null) {
        deleteStmt.close();
      }
    }
  } // end of delete

}
