package OULAD.dao;

import OULAD.model.Courses;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/11/2020
 */
public class CoursesDao {

  private static CoursesDao instance = null;
  protected ConnectionManager connectionManager;

  protected CoursesDao() {
    connectionManager = new ConnectionManager();
  }

  public static CoursesDao getInstance() {
    if (instance == null) {
      instance = new CoursesDao();
    }
    return instance;
  }

  public Courses create(Courses course) throws SQLException {
    String insertCourses = "INSERT INTO "
        + "courses(code_module,code_presentation,module_presentation_length) VALUES(?,?,?);";
    Connection connection = null;
    PreparedStatement insertStmt = null;
    try {
      connection = connectionManager.getConnection();
      insertStmt = connection.prepareStatement(insertCourses);

      insertStmt.setString(1, course.getCode_module());
      insertStmt.setString(2, course.getCode_presentation());
      insertStmt.setInt(3, course.getModule_presentation_length());

      insertStmt.executeUpdate();

      return course;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (insertStmt != null) {
        insertStmt.close();
      }
    }
  } // end of create

  public Courses getCourses(String code_module, String code_presentation) throws SQLException {
    String selectCourse = "SELECT * FROM courses WHERE code_module=? AND code_presentation=?;";
    Connection connection = null;
    PreparedStatement selectStmt = null;
    ResultSet results = null;
    try {
      connection = connectionManager.getConnection();
      selectStmt = connection.prepareStatement(selectCourse);
      selectStmt.setString(1, code_module);
      selectStmt.setString(2, code_presentation);
      results = selectStmt.executeQuery();

      if (results.next()) {
        String resultCode_module = results.getString("code_module");
        String resultCode_presentation = results.getString("code_presentation");
        int module_presentation_length = results.getInt("module_presentation_length");
        Courses course = new Courses(resultCode_module, resultCode_presentation,
            module_presentation_length);

        return course;
      }
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (selectStmt != null) {
        selectStmt.close();
      }
      if (results != null) {
        results.close();
      }
    }
    return null;

  } // end of get
  
  public List<Courses> getCoursesByModule(String code_module) throws SQLException {
	  List<Courses> courseList = new ArrayList<>();
	  String selectCourse = "SELECT * FROM courses WHERE code_module=?;";
	    Connection connection = null;
	    PreparedStatement selectStmt = null;
	    ResultSet results = null;
	    try {
	      connection = connectionManager.getConnection();
	      selectStmt = connection.prepareStatement(selectCourse);
	      selectStmt.setString(1, code_module);
	      results = selectStmt.executeQuery();

	      while (results.next()) {
	        String resultCode_module = results.getString("code_module");
	        String resultCode_presentation = results.getString("code_presentation");
	        int module_presentation_length = results.getInt("module_presentation_length");
	        Courses course = new Courses(resultCode_module, resultCode_presentation,
	            module_presentation_length);

	        courseList.add(course);
	      }
	    } catch (SQLException e) {
	      e.printStackTrace();
	      throw e;
	    } finally {
	      if (connection != null) {
	        connection.close();
	      }
	      if (selectStmt != null) {
	        selectStmt.close();
	      }
	      if (results != null) {
	        results.close();
	      }
	    }
	    return courseList;
  }

  public List<Courses> getAllCourses() throws SQLException {
    List<Courses> courseList = new ArrayList<>();
    String selectCourses = "SELECT * FROM courses;";
    Connection connection = null;
      PreparedStatement selectStmt = null;
      ResultSet results = null;
      try {
        connection = connectionManager.getConnection();
        selectStmt = connection.prepareStatement(selectCourses);
        results = selectStmt.executeQuery();
  
        while (results.next()) {
          String resultCode_module = results.getString("code_module");
          String resultCode_presentation = results.getString("code_presentation");
          int module_presentation_length = results.getInt("module_presentation_length");
          Courses course = new Courses(resultCode_module, resultCode_presentation,
              module_presentation_length);
  
          courseList.add(course);
        }
      } catch (SQLException e) {
        e.printStackTrace();
        throw e;
      } finally {
        if (connection != null) {
          connection.close();
        }
        if (selectStmt != null) {
          selectStmt.close();
        }
        if (results != null) {
          results.close();
        }
      }
      return courseList;
        
  }

  public Courses updateModule_presentation_length(Courses course, int newModule_presentation_length)
      throws SQLException {
    String updateModule_presentation_length = "UPDATE courses SET module_presentation_length=? "
        + "WHERE code_module=? AND code_presentation=?;";
    Connection connection = null;
    PreparedStatement updateStmt = null;
    try {
      connection = connectionManager.getConnection();
      updateStmt = connection.prepareStatement(updateModule_presentation_length);
      updateStmt.setInt(1, newModule_presentation_length);
      updateStmt.setString(2, course.getCode_module());
      updateStmt.setString(3, course.getCode_presentation());
      updateStmt.executeUpdate();

      // Update the company param before returning to the caller.
      course.setModule_presentation_length(newModule_presentation_length);
      return course;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (updateStmt != null) {
        updateStmt.close();
      }
    }

  } // end of update

  public Courses delete(Courses course) throws SQLException {
    String deleteCourse = "DELETE FROM courses WHERE code_module=? AND code_presentation=?;";
    Connection connection = null;
    PreparedStatement deleteStmt = null;
    try {
      connection = connectionManager.getConnection();
      deleteStmt = connection.prepareStatement(deleteCourse);
      deleteStmt.setString(1, course.getCode_module());
      deleteStmt.setString(2, course.getCode_presentation());
      deleteStmt.executeUpdate();

      // Return null so the caller can no longer operate on the Persons instance.
      return null;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (deleteStmt != null) {
        deleteStmt.close();
      }
    }
  } // end of delete

}
