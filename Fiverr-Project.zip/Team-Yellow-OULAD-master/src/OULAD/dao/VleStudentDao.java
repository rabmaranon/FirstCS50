package OULAD.dao;

import OULAD.model.Vle;
import OULAD.model.VleStudent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VleStudentDao {
    protected ConnectionManager connectionManager;

    private static VleStudentDao instance = null;
    protected VleStudentDao() {
        connectionManager = new ConnectionManager();
    }
    public static VleStudentDao getInstance() {
        if(instance == null) {
            instance = new VleStudentDao();
        }
        return instance;
    }

    public VleStudent create(VleStudent vleStudent) throws SQLException {
        String insertStudent = "INSERT INTO student_vle" +
                "(id_site, id_student, code_module, code_presentation, vle_date, click_sum) " +
                "VALUES(?,?,?,?,?,?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        ResultSet resultKey = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertStudent);
            insertStmt.setInt(1, vleStudent.getId_site());
            insertStmt.setInt(2, vleStudent.getId_student());
            insertStmt.setString(3, vleStudent.getCode_module());
            insertStmt.setString(4, vleStudent.getCode_presentation());
            insertStmt.setInt(5, vleStudent.getVle_date());
            insertStmt.setInt(6, vleStudent.getClick_sum());
            insertStmt.executeUpdate();
            return vleStudent;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }
    }

    /**
     * Get student by their student id. Returns a list of VleStudent
     * @param id_student
     * @return
     * @throws SQLException
     */
    public List<VleStudent> getVleStudentById(int id_student) throws SQLException {
        List<VleStudent> studentList = new ArrayList<VleStudent>();
        String getStudentById = "SELECT id_site, id_student, code_module, code_presentation, vle_date, click_sum " +
                "FROM student_vle WHERE id_student=?;";
        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet results = null;
        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(getStudentById);
            selectStmt.setInt(1, id_student);
            results = selectStmt.executeQuery();
            while (results.next()) {
                int rId_site =results.getInt("id_site");
                int rId_student = results.getInt("id_student");
                String rCode_module = results.getString("code_module");
                String rCode_representation = results.getString("code_presentation");
                int rVle_date = results.getInt("vle_date");
                int rClick_sum = results.getInt("click_sum");
                VleStudent student = new VleStudent(rId_site, rId_student, rCode_module,
                        rCode_representation, rVle_date, rClick_sum);
                studentList.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(selectStmt != null) {
                selectStmt.close();
            }
            if(results != null) {
                results.close();
            }
        }
        return studentList;
    }

    public VleStudent delete(VleStudent student) throws SQLException {
        String deleteStudent = "DELETE FROM student_vle WHERE id_site = ? AND id_student=? " +
                "AND code_module=? AND code_presentation=?;";
        Connection connection = null;
        PreparedStatement deleteStmt = null;
        try {
            connection = connectionManager.getConnection();
            deleteStmt = connection.prepareStatement(deleteStudent);
            deleteStmt.setInt(1, student.getId_site());
            deleteStmt.setInt(2, student.getId_student());
            deleteStmt.setString(3, student.getCode_module());
            deleteStmt.setString(4, student.getCode_presentation());
            deleteStmt.executeUpdate();
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(deleteStmt != null) {
                deleteStmt.close();
            }
        }
    }
}
