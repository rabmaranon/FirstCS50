package OULAD.dao;

import OULAD.model.Assessments;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/13/2020
 */
public class AssessmentsDao {

  private static AssessmentsDao instance = null;
  protected ConnectionManager connectionManager;

  protected AssessmentsDao() {
    connectionManager = new ConnectionManager();
  }

  public static AssessmentsDao getInstance() {
    if (instance == null) {
      instance = new AssessmentsDao();
    }
    return instance;
  }

  public Assessments create(Assessments assessment) throws SQLException {
    String insertAssessments = "INSERT INTO "
        + "assessments(code_module,code_presentation,id_assessment,"
        + "assessment_type,assessment_date, assessment_weight) VALUES(?,?,?,?,?,?);";
    Connection connection = null;
    PreparedStatement insertStmt = null;
    try {
      connection = connectionManager.getConnection();
      insertStmt = connection.prepareStatement(insertAssessments);

      insertStmt.setString(1, assessment.getCode_module());
      insertStmt.setString(2, assessment.getCode_presentation());
      insertStmt.setInt(3, assessment.getId_assessment());
      insertStmt.setString(4, assessment.getAssessment_type());
      insertStmt.setInt(5, assessment.getAssessment_date());
      insertStmt.setBigDecimal(6,assessment.getAssessment_weight());

      insertStmt.executeUpdate();

      return assessment;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (insertStmt != null) {
        insertStmt.close();
      }
    }
  } // end of create


    public Map<String, Integer> compareAssessmentTypes() throws SQLException {
    String compareAssessments = "SELECT T.assessment_type as type, count(*) as total \n" + 
        "FROM\n" + 
        " (SELECT assessments.code_module, assessments.code_presentation, \n" + 
        " student_info.id_student, student_info.final_result, assessments.assessment_type\n" + 
        " FROM student_info \n" + 
        "   JOIN student_assessment\n" + 
        "   ON student_info.id_student = student_assessment.id_student\n" + 
        "   JOIN assessments\n" + 
        "   ON assessments.code_module = student_info.code_module\n" + 
        "   AND assessments.code_presentation = student_info.code_presentation\n" + 
        "   WHERE student_info.final_result='Pass' OR student_info.final_result='Distinction'\n" + 
        "   GROUP BY assessments.code_module, assessments.code_presentation, \n" + 
        "     student_info.id_student, assessments.assessment_type) AS T\n" + 
        "GROUP BY T.assessment_type\n" + 
        "ORDER BY count(*) DESC";
    Map <String, Integer> assessmentTypeToCount = new HashMap<>();
    Connection connection = null;
    PreparedStatement selectStmt = null;
    ResultSet results = null;

    try {
        connection = connectionManager.getConnection();
        selectStmt = connection.prepareStatement(compareAssessments);
        results = selectStmt.executeQuery();
        
        while (results.next()) {
          String type = results.getString("type");
          Integer total = results.getInt("total");
          assessmentTypeToCount.put(type, total);
        }
    } catch (SQLException e) {
        e.printStackTrace();
        throw e;
      } finally {
        if (connection != null) {
          connection.close();
        }
        if (selectStmt != null) {
          selectStmt.close();
        }
        if (results != null) {
          results.close();
        }
      }
      return assessmentTypeToCount;

  }

  public Assessments getAssessments(String code_module, String code_presentation, int id_assessment)
      throws SQLException {
    String selectAssessment =
        "SELECT * FROM assessments WHERE code_module=? AND code_presentation=?"
            + "AND id_assessment=?;";
    Connection connection = null;
    PreparedStatement selectStmt = null;
    ResultSet results = null;
    try {
      connection = connectionManager.getConnection();
      selectStmt = connection.prepareStatement(selectAssessment);
      selectStmt.setString(1, code_module);
      selectStmt.setString(2, code_presentation);
      selectStmt.setInt(3, id_assessment);
      results = selectStmt.executeQuery();

      if (results.next()) {
        String resultCode_module = results.getString("code_module");
        String resultCode_presentation = results.getString("code_presentation");
        int resultId_assessment = results.getInt("id_assessment");
        String resultAssessment_type = results.getString("assessment_type");
        int resultAssessment_date = results.getInt("assessment_date");
        BigDecimal resultAssessment_weight = results.getBigDecimal("assessment_weight");
        Assessments assessment = new Assessments(resultCode_module, resultCode_presentation,
            resultId_assessment, resultAssessment_type, resultAssessment_date,
            resultAssessment_weight);

        return assessment;
      }
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (selectStmt != null) {
        selectStmt.close();
      }
      if (results != null) {
        results.close();
      }
    }
    return null;

  } // end of get

  public Assessments delete(Assessments assessment) throws SQLException {
    String deleteAssessment = "DELETE FROM assessments WHERE code_module=? AND code_presentation=? "
        + "AND id_assessment=?;";
    Connection connection = null;
    PreparedStatement deleteStmt = null;
    try {
      connection = connectionManager.getConnection();
      deleteStmt = connection.prepareStatement(deleteAssessment);
      deleteStmt.setString(1, assessment.getCode_module());
      deleteStmt.setString(2, assessment.getCode_presentation());
      deleteStmt.setInt(3,assessment.getId_assessment());
      deleteStmt.executeUpdate();

      // Return null so the caller can no longer operate on the Persons instance.
      return null;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (deleteStmt != null) {
        deleteStmt.close();
      }
    }
  } // end of delete

}
