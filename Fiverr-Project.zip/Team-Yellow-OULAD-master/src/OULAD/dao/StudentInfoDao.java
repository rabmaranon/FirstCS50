package OULAD.dao;

import OULAD.model.StudentInfo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/11/2020
 */
public class StudentInfoDao {

  private static StudentInfoDao instance = null;
  protected ConnectionManager connectionManager;

  protected StudentInfoDao() {
    connectionManager = new ConnectionManager();
  }

  public static StudentInfoDao getInstance() {
    if (instance == null) {
      instance = new StudentInfoDao();
    }
    return instance;
  }

  public StudentInfo create(StudentInfo studentInfo) throws SQLException {
    String insertStudentInfo = "INSERT INTO student_info(code_module,code_presentation,id_student,"
        + "gender,imd_band,highest_education,"
        + "age_band,num_of_prev_attempts,studied_credits,"
        + "region,disability,final_result) VALUES(?,?,?,?,?,?,?,?,?,?,?,?);";
    Connection connection = null;
    PreparedStatement insertStmt = null;
    try {
      connection = connectionManager.getConnection();
      insertStmt = connection.prepareStatement(insertStudentInfo);

      insertStmt.setString(1, studentInfo.getCode_module());
      insertStmt.setString(2, studentInfo.getCode_presentation());
      insertStmt.setInt(3, studentInfo.getId_student());
      insertStmt.setString(4, studentInfo.getGender());
      insertStmt.setString(5, studentInfo.getImd_band());
      insertStmt.setString(6, studentInfo.getHighest_education());
      insertStmt.setString(7, studentInfo.getAge_band());
      insertStmt.setInt(8, studentInfo.getNum_of_prev_attempts());
      insertStmt.setInt(9, studentInfo.getStudied_credits());
      insertStmt.setString(10, studentInfo.getRegion());
      insertStmt.setString(11, studentInfo.getDisability());
      insertStmt.setString(12, studentInfo.getFinal_result());

      insertStmt.executeUpdate();

      return studentInfo;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (insertStmt != null) {
        insertStmt.close();
      }
    }
  } // end of create

  public StudentInfo getStudentInfo(String code_module, String code_presentation, int id_student)
      throws SQLException {
    String selectStudentInfo = "SELECT * FROM student_info "
        + "WHERE code_module=? AND code_presentation=? AND id_student=?;";
    Connection connection = null;
    PreparedStatement selectStmt = null;
    ResultSet results = null;
    try {
      connection = connectionManager.getConnection();
      selectStmt = connection.prepareStatement(selectStudentInfo);
      selectStmt.setString(1, code_module);
      selectStmt.setString(2, code_presentation);
      selectStmt.setInt(3, id_student);
      results = selectStmt.executeQuery();

      if (results.next()) {
        String resultCode_module = results.getString("code_module");
        String resultCode_presentation = results.getString("code_presentation");
        int resultId_student = results.getInt("id_student");
        String resultGender = results.getString("gender");
        String resultImd_band = results.getString("imd_band");
        String resultHighest_education = results.getString("highest_education");
        String resultAge_band = results.getString("age_band");
        int resultNum_of_prev_attempts = results.getInt("num_of_prev_attempts");
        int resultStudied_credits = results.getInt("studied_credits");
        String resultRegion = results.getString("region");
        String resultDisability = results.getString("disability");
        String resultFinal_result = results.getString("final_result");

        StudentInfo studentInfo = new StudentInfo(resultCode_module, resultCode_presentation,
            resultId_student, resultGender, resultImd_band, resultHighest_education, resultAge_band,
            resultNum_of_prev_attempts, resultStudied_credits, resultRegion, resultDisability,
            resultFinal_result);

        return studentInfo;
      }
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (selectStmt != null) {
        selectStmt.close();
      }
      if (results != null) {
        results.close();
      }
    }
    return null;

  } // end of get

  public StudentInfo updateNum_of_prev_attempts(StudentInfo studentInfo,
      int newNum_of_prev_attempts)
      throws SQLException {
    String updateNum_of_prev_attempts = "UPDATE student_info SET num_of_prev_attempts=? "
        + "WHERE code_module=? AND code_presentation=? AND id_student=?;";
    Connection connection = null;
    PreparedStatement updateStmt = null;
    try {
      connection = connectionManager.getConnection();
      updateStmt = connection.prepareStatement(updateNum_of_prev_attempts);
      updateStmt.setInt(1, newNum_of_prev_attempts);
      updateStmt.setString(2, studentInfo.getCode_module());
      updateStmt.setString(3, studentInfo.getCode_presentation());
      updateStmt.setInt(4, studentInfo.getId_student());
      updateStmt.executeUpdate();

      // Update the company param before returning to the caller.
      studentInfo.setNum_of_prev_attempts(newNum_of_prev_attempts);
      return studentInfo;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (updateStmt != null) {
        updateStmt.close();
      }
    }

  } // end of update

  public StudentInfo updateStudied_credits(StudentInfo studentInfo, int newStudied_credits)
      throws SQLException {
    String updateStudied_credits = "UPDATE student_info SET studied_credits=? "
        + "WHERE code_module=? AND code_presentation=? AND id_student=?;";
    Connection connection = null;
    PreparedStatement updateStmt = null;
    try {
      connection = connectionManager.getConnection();
      updateStmt = connection.prepareStatement(updateStudied_credits);
      updateStmt.setInt(1, newStudied_credits);
      updateStmt.setString(2, studentInfo.getCode_module());
      updateStmt.setString(3, studentInfo.getCode_presentation());
      updateStmt.setInt(4, studentInfo.getId_student());
      updateStmt.executeUpdate();

      // Update the company param before returning to the caller.
      studentInfo.setStudied_credits(newStudied_credits);
      return studentInfo;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (updateStmt != null) {
        updateStmt.close();
      }
    }

  } // end of update

  public List<StudentInfo> getStudentsByRegion(String region) throws SQLException {
    List<StudentInfo> studentList = new ArrayList<>();
    String selectTotalCredits = "SELECT * FROM student_info "
        + "WHERE region=?;";
    Connection connection = null;
      PreparedStatement selectStmt = null;
      ResultSet results = null;
      try {
        connection = connectionManager.getConnection();
          selectStmt = connection.prepareStatement(selectTotalCredits);
          selectStmt.setString(1, region);
          results = selectStmt.executeQuery();

          while (results.next()) {
            String resultCode_module = results.getString("code_module");
              String resultCode_presentation = results.getString("code_presentation");
              int resultId_student = results.getInt("id_student");
              String resultGender = results.getString("gender");
              String resultImd_band = results.getString("imd_band");
              String resultHighest_education = results.getString("highest_education");
              String resultAge_band = results.getString("age_band");
              int resultNum_of_prev_attempts = results.getInt("num_of_prev_attempts");
              int resultStudied_credits = results.getInt("studied_credits");
              String resultRegion = results.getString("region");
              String resultDisability = results.getString("disability");
              String resultFinal_result = results.getString("final_result");

              StudentInfo studentInfo = new StudentInfo(resultCode_module, resultCode_presentation,
                  resultId_student, resultGender, resultImd_band, resultHighest_education, resultAge_band,
                  resultNum_of_prev_attempts, resultStudied_credits, resultRegion, resultDisability,
                  resultFinal_result);
              
              studentList.add(studentInfo);
          }
      } catch (SQLException e) {
          e.printStackTrace();
          throw e;
        } finally {
          if (connection != null) {
            connection.close();
          }
          if (selectStmt != null) {
            selectStmt.close();
          }
          if (results != null) {
            results.close();
          }
        }
        return studentList;
  }
  
  public Map<String, Double> getModulePassRate() throws SQLException {
      String selectPassRate = "SELECT (COUNT(IF(student_info.final_result = "
              + "\"PASS\", 1, NULL))/COUNT(student_info.final_result)) AS count, "
              + "student_info.code_module as module FROM student_info GROUP BY student_info.code_module";
      Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet results = null;
        Map<String, Double> modulePassRate = new HashMap<>();
        try {
          connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(selectPassRate);
            results = selectStmt.executeQuery();

            while (results.next()) {
              Double resultCount = results.getDouble("count");
              String resultCode_module = results.getString("module");
              modulePassRate.put(resultCode_module, resultCount);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
          } finally {
            if (connection != null) {
              connection.close();
            }
            if (selectStmt != null) {
              selectStmt.close();
            }
            if (results != null) {
              results.close();
            }
          }
          return modulePassRate;
    }

  public StudentInfo delete(StudentInfo studentInfo) throws SQLException {
    String deleteStudentInfo = "DELETE FROM student_info "
        + "WHERE code_module=? AND code_presentation=? AND id_student=?;";
    Connection connection = null;
    PreparedStatement deleteStmt = null;
    try {
      connection = connectionManager.getConnection();
      deleteStmt = connection.prepareStatement(deleteStudentInfo);
      deleteStmt.setString(1, studentInfo.getCode_module());
      deleteStmt.setString(2, studentInfo.getCode_presentation());
      deleteStmt.setInt(3, studentInfo.getId_student());
      deleteStmt.executeUpdate();

      // Return null so the caller can no longer operate on the Persons instance.
      return null;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (deleteStmt != null) {
        deleteStmt.close();
      }
    }
  } // end of delete

}
