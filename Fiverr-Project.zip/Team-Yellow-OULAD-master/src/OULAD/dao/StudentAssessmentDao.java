package OULAD.dao;

import OULAD.model.StudentAssessment;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author Yuhan Zhang
 * @project Team-Yellow-OULAD
 * @date 7/13/2020
 */
public class StudentAssessmentDao {

  private static StudentAssessmentDao instance = null;
  protected ConnectionManager connectionManager;

  protected StudentAssessmentDao() {
    connectionManager = new ConnectionManager();
  }

  public static StudentAssessmentDao getInstance() {
    if (instance == null) {
      instance = new StudentAssessmentDao();
    }
    return instance;
  }

  public StudentAssessment create(StudentAssessment studentAssessment) throws SQLException {
    String insertAssessments = "INSERT INTO "
        + "student_assessment(code_module,code_presentation,id_student,id_assessment"
        + ",date_submitted,is_banked,score) VALUES(?,?,?,?,?,?,?);";
    Connection connection = null;
    PreparedStatement insertStmt = null;
    try {
      connection = connectionManager.getConnection();
      insertStmt = connection.prepareStatement(insertAssessments);

      insertStmt.setString(1, studentAssessment.getCode_module());
      insertStmt.setString(2, studentAssessment.getCode_presentation());
      insertStmt.setInt(3, studentAssessment.getId_student());
      insertStmt.setInt(4, studentAssessment.getId_assessment());
      insertStmt.setInt(5,studentAssessment.getDate_submitted());
      insertStmt.setInt(6,studentAssessment.getIs_banked());
      insertStmt.setFloat(7,studentAssessment.getScore());;

      insertStmt.executeUpdate();

      return studentAssessment;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (insertStmt != null) {
        insertStmt.close();
      }
    }
  } // end of create

  public StudentAssessment getStudentAssessment(String code_module, String code_presentation,
      int id_student, int id_assessment)
      throws SQLException {
    String selectStudentAssessment =
        "SELECT * FROM student_assessment WHERE code_module=? AND code_presentation=?"
            + "AND id_student=? AND id_assessment=?;";
    Connection connection = null;
    PreparedStatement selectStmt = null;
    ResultSet results = null;
    try {
      connection = connectionManager.getConnection();
      selectStmt = connection.prepareStatement(selectStudentAssessment);
      selectStmt.setString(1, code_module);
      selectStmt.setString(2, code_presentation);
      selectStmt.setInt(3, id_student);
      selectStmt.setInt(4, id_assessment);
      results = selectStmt.executeQuery();

      if (results.next()) {
        String resultCode_module = results.getString("code_module");
        String resultCode_presentation = results.getString("code_presentation");
        int resultId_student = results.getInt("id_student");
        int resultId_assessment = results.getInt("id_assessment");
        int resultDate_submitted = results.getInt("date_submitted");
        int resultIs_banked = results.getInt("is_banked");
        float resultScore = results.getFloat("score");
        StudentAssessment studentAssessment = new StudentAssessment(resultCode_module,
            resultCode_presentation,
            resultId_student, resultId_assessment, resultDate_submitted, resultIs_banked,
            resultScore);

        return studentAssessment;
      }
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (selectStmt != null) {
        selectStmt.close();
      }
      if (results != null) {
        results.close();
      }
    }
    return null;

  } // end of get

  public StudentAssessment updateScore(StudentAssessment studentAssessment,
      float newScore)
      throws SQLException {
    String updateSCore = "UPDATE student_assessment SET score=? "
        + "WHERE code_module=? AND code_presentation=? AND id_student=? AND id_assessment=?;";
    Connection connection = null;
    PreparedStatement updateStmt = null;
    try {
      connection = connectionManager.getConnection();
      updateStmt = connection.prepareStatement(updateSCore);
      updateStmt.setFloat(1, newScore);
      updateStmt.setString(2, studentAssessment.getCode_module());
      updateStmt.setString(3, studentAssessment.getCode_presentation());
      updateStmt.setInt(4, studentAssessment.getId_student());
      updateStmt.setInt(5, studentAssessment.getId_assessment());
      updateStmt.executeUpdate();

      // Update the company param before returning to the caller.
      studentAssessment.setScore(newScore);
      return studentAssessment;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (updateStmt != null) {
        updateStmt.close();
      }
    }

  } // end of update

  public StudentAssessment delete(StudentAssessment studentAssessment) throws SQLException {
    String deleteStudentAssessment =
        "DELETE FROM student_assessment WHERE code_module=? AND code_presentation=? "
            + "AND id_student=? AND id_assessment=?;";
    Connection connection = null;
    PreparedStatement deleteStmt = null;
    try {
      connection = connectionManager.getConnection();
      deleteStmt = connection.prepareStatement(deleteStudentAssessment);
      deleteStmt.setString(1, studentAssessment.getCode_module());
      deleteStmt.setString(2, studentAssessment.getCode_presentation());
      deleteStmt.setInt(3, studentAssessment.getId_student());
      deleteStmt.setInt(4, studentAssessment.getId_assessment());
      deleteStmt.executeUpdate();

      // Return null so the caller can no longer operate on the Persons instance.
      return null;
    } catch (SQLException e) {
      e.printStackTrace();
      throw e;
    } finally {
      if (connection != null) {
        connection.close();
      }
      if (deleteStmt != null) {
        deleteStmt.close();
      }
    }
  } // end of delete
}
