package OULAD.dao;

import OULAD.model.Vle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VleDao {
    protected ConnectionManager connectionManager;

    private static VleDao instance = null;
    protected VleDao() {
        connectionManager = new ConnectionManager();
    }
    public static VleDao getInstance() {
        if(instance == null) {
            instance = new VleDao();
        }
        return instance;
    }

    public Vle create(Vle vle) throws SQLException {
        String insertVle = "INSERT INTO vle(id_site, code_module, code_presentation, activity_type) " +
                "VALUES(?,?,?,?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        ResultSet resultKey = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertVle);
            insertStmt.setInt(1, vle.getId_site());
            insertStmt.setString(2, vle.getCode_module());
            insertStmt.setString(3, vle.getCode_presentation());
            insertStmt.setString(4, vle.getActivity_type());

            insertStmt.executeUpdate();
            return vle;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }

    }

    public List<Vle> getVleByIdSite(int id_site) throws SQLException {
        List<Vle> vleList = new ArrayList<Vle>();
        String selectVle = "SELECT id_site, code_module, code_presentation, activity_type FROM vle WHERE id_site=?;";
        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet results = null;
        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(selectVle);
            selectStmt.setInt(1, id_site);
            results = selectStmt.executeQuery();
            while (results.next()) {
                int rId_site = results.getInt("id_site");
                String rCode_module = results.getString("code_module");
                String rCode_representation = results.getString("code_presentation");
                String rActivity_type = results.getString("activity_type");

                Vle vle =
                        new Vle(rId_site, rCode_module, rCode_representation, rActivity_type);
                vleList.add(vle);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(selectStmt != null) {
                selectStmt.close();
            }
            if(results != null) {
                results.close();
            }
        }
        return vleList;
    }

    public Vle getVleByPrimaryKeys(int id_site, String code_module, String code_presentation) throws SQLException {
        String selectVle = "SELECT id_site, code_module, code_presentation, activity_type " +
                "FROM vle " +
                "WHERE id_site=? AND code_module=? AND code_presentation=?;";
        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet results = null;
        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(selectVle);
            selectStmt.setInt(1, id_site);
            selectStmt.setString(2, code_module);
            selectStmt.setString(3, code_presentation);
            results = selectStmt.executeQuery();
            while (results.next()) {
                int rId_site = results.getInt("id_site");
                String rCode_module = results.getString("code_module");
                String rCode_representation = results.getString("code_presentation");
                String rActivity_type = results.getString("activity_type");
                Vle vle =
                        new Vle(rId_site, rCode_module, rCode_representation, rActivity_type);
                return vle;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(selectStmt != null) {
                selectStmt.close();
            }
            if(results != null) {
                results.close();
            }
        }
        return null;
    }

    public Vle delete(Vle vle) throws SQLException {
        String deleteVle = "DELETE FROM vle Where id_site=? AND code_module=? AND code_presentation=?;";
        Connection connection = null;
        PreparedStatement deleteStmt = null;
        try {
            connection = connectionManager.getConnection();
            deleteStmt = connection.prepareStatement(deleteVle);
            deleteStmt.setInt(1, vle.getId_site());
            deleteStmt.setString(2, vle.getCode_module());
            deleteStmt.setString(3, vle.getCode_presentation());
            deleteStmt.executeUpdate();
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if(connection != null) {
                connection.close();
            }
            if(deleteStmt != null) {
                deleteStmt.close();
            }
        }
    }
}
